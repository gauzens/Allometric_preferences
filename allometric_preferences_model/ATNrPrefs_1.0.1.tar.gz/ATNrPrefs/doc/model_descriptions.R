### This is an R script tangled from 'model_descriptions.ltx'
