#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// #include <Rcpp.h>
using namespace arma;
using namespace Rcpp;

// generate documentation with:
// Rcpp::compileAttributes()           # this updates the Rcpp layer from C++ to R
// roxygen2::roxygenize(roclets="rd")  # this updates the documentation based on roxygen comments

//' @name Schneider_arma_pref
//' @title Store parameters and functions associated to Schneider with prefs
//' @description project specific


class Schneider_arma_pref{
public:
  int nb_s; // number of species
  int nb_b; // number of basal species
  int nb_n = 2; // number of nutrients
  int n_tot = nb_s + nb_n; // bool prefs MORE PRECISE?
  // global nutrient turn over rate (rate of replenishment)
  // used in calculating change in nutrient concentration
  double D = 0.25;
  double q;
  double ext;
  double temperature;

  vec X; // metabolic rates
  vec total_X; // population metabolism
  vec e; // assimilation efficiencies
  vec r; // growth rates of plants
  vec S; // maximal nutrient level
  vec c; // interference competition
  vec out_fluxes; // out fluxes for all species
  // body masses
  vec BM ;
  vec log_BM;
  
  // biomasses
  vec bioms;
  // r*G for plants, as there is no need to compute it at each ODE call
  
  // NumericVector test;
  vec p;
  // Coltor of derivatives
  vec dB;
  // 
  
  Mat<int> fw; 
  
  mat b;
  // handling times
  mat h;
  // functional response
  mat F;
  // consumption rates
  mat w;

  // plants nutrient uptake efficiency (K(i,j): plant i on nutrient j)
  mat K; //!!!!!!!! change to same row*col in inits in R
  // relative content in the plant species' biomass
  mat V; //rows = nuts, cols = plants

  // internal variables for optimisation
  vec G; // species specific growth factor Gi
  vec pow_bioms;
  vec low;
  vec uptake;
  vec bioms_non_nut;
  vec sum_bioms;
  vec prod_vec;
  uvec prey;

  mat wbh_mat;
  mat wb_mat;


  vec d_skew;

  // iterators
  int res;
  int cons;
  vec::iterator res_end;

  // slicers
  uvec animals;
  uvec plants;
  uvec nut;
  uvec non_nut;
  uvec extinct;
  
  Schneider_arma_pref(int ns, int nb, int nn):
    nb_s(ns), nb_b(nb), nb_n(nn) {
      int n_tot = nb_s + nb_n;
      int n_cons = nb_s - nb_b;
      // initialise vectors to 0
      X.zeros(nb_s);
      e.zeros(nb_s);
      r.zeros(nb_b);
      S.zeros(nb_n);
      G.zeros(nb_b);
      pow_bioms.zeros(nb_s);
      low.zeros(n_cons);
      dB.zeros(n_tot);
      uptake.zeros(nb_b);
      out_fluxes.zeros(nb_s);
      low.zeros(n_cons);
      bioms_non_nut.zeros(nb_s);
      BM.ones(nb_s);
      sum_bioms.zeros(n_cons);
      

      // matrices
      b.zeros(nb_s, n_cons);
      h.zeros(nb_s, n_cons);
      F.zeros(nb_s, n_cons);
      w.zeros(nb_s, n_cons);
      K.zeros(nb_n, nb_b);
      V.zeros(nb_n, nb_b);
      wb_mat.zeros(nb_s, n_cons);
      wbh_mat.zeros(n_cons, nb_s);

      // iterator
      res_end = G.end();


      // slicers TODO check optional argument N, =100 by default
      // but inconsistant with this: https://stackoverflow.com/questions/25790634/how-to-create-a-vector-from-1n-in-c-armadillo
      animals = linspace<uvec>(nb_n + nb_b, n_tot-1, n_cons);
      plants = linspace<uvec>(nb_n, nb_n + nb_b-1, nb_b);
      nut = linspace<uvec>(0, nb_n-1, nb_n);
      non_nut = linspace<uvec>(nb_n, n_tot-1, nb_s);
    }

  void initialisations(){
    // intermediate matrices for the functional response:
    // matrices used for the computation of IN feeding rates
    // wb_mat; w * b (upper part of F)
    wb_mat = (w%b);
    // adding efficiencies
    // wb_mat.each_col() *= e; !!! check that option later
    // wbh_mat: used in the below part of F, rows = cons, cols = res
    wbh_mat = (w%b%h).t();
    // log_BM = log10(BM);
  }

  void print(){
    Rcpp::Rcout << "nb_s:"  << std::endl << nb_s << std::endl;
    Rcpp::Rcout << "nb_b:"  << std::endl << nb_b << std::endl; 
    Rcpp::Rcout << "bioms: " << bioms << std::endl; 
    Rcpp::Rcout << "G: " << G << std::endl; 
    // Rcout << " prey" << prey << std::endl;
  }
  
    mat compute_w(vec bioms, vec log_BM, double Temperature){
      // I loop over cons first for simplicity
    // could be optimised by looping over resources first to match C storage of matricies
    double prod, alpha, omega, xi, total;
    
    // I rescale the biomasses. that fall into the values that I used to predict sdn paramters.
    // note: scale to hve species with the max generalsim to reach 4
    for (cons = nb_b; cons != (nb_s-1); cons++){
      prey = find(fw.col(cons)>0);
      vec bioms_noNut = bioms(non_nut);
      vec bioms_prey = bioms_noNut(prey);
      sum_bioms(cons - nb_b) = sum(bioms_prey);
    }
    //prod_vec = (sum_bioms / max(sum_bioms))*4;
    prod_vec = sum_bioms;

    for (cons = nb_b; cons != (nb_s-1); cons++){
      
      prod = prod_vec(cons - nb_b);

      // Rcout << log_BM(cons) << prod << temperature << std::endl;
      alpha = -9.6633 - 1.7765*log_BM(cons) + 5.55*prod - 0.246*temperature + 0.1647*prod*temperature;
      omega = exp(-4.0216 + 0.4459*log_BM(cons) + 0.9355*prod + 0.3098*temperature - 0.1133*prod*temperature);
      xi    = -0.7831 + 0.65268*log_BM(cons) - 0.01607*prod + 0.20712*temperature - 0.08349*prod*temperature;
      
      if (omega < 0){
        Rcout << "params " << log_BM(cons) << " " << prod << " " << temperature << std::endl;
      }

      d_skew = as<arma::vec>(skew_norm(as<NumericVector>(wrap(log_BM)), xi, omega, alpha));
      // Rcout << "dskew3: " << d_skew << std::endl;
      // set values where b = 0 to 0 (no foraging effort on not eaten species)
      prey = find(b.col(cons - nb_b) == 0);
      d_skew(prey).fill(0.0);
      total = sum(d_skew);
      if (total > 0.0){
        d_skew = d_skew/total;
      }
      w.col(cons-nb_b) = d_skew;
       // Rcout << "end conpute w " << std::endl;

  //     total = 0.0;
  //     for (res = 0; res != nb_s; res++){
  //       // Rcout << *res << " " << *cons << "  ||  ";
  //       if (fw(res, cons) > 0){
  //         w(res, cons-nb_b) = skew_norm(log_BM(res), xi, omega, alpha);
  //         // Rcout << "resBM " << log_BM(res) << "  alpha" << alpha << "  omega: " << omega << "  eps: " << eps << std::endl;
  //         Rcout << "w: " << w(res, cons - nb_b) << "  cons: " << cons - nb_b << "  res: " << res << std::endl;
  //         total = total +  w(res, cons-nb_b);
  //       }
  //     }
      
  //     // Rcout << std::endl;
  //     Rcout << "w_tot: " << total << "   cons: " << cons << std::endl;
  //     if (total > 0.0) {
  //       w.col(cons-nb_b) = w.col(cons-nb_b) / total;
  //     }else{
  //       w.col(cons-nb_b) = 0.0;
  //     }

    }
    return(w);
  }
  
    NumericVector skew_norm(NumericVector x, double xi, double omega, double alpha){
    // no skew normal function in Rcpp
    // have to call the R function from C directly
    // the R function return a pointer (SEXP) that has to be converted to double with REAL
    //  !!! library sn needs to be loaded in the R session
    Rcpp::Environment base("package:sn");
    Rcpp::Function dsn_r = base["dsn"];
    // Rcout << "dsn " << xi << " " << omega << " " << alpha << std::endl;
    NumericVector a =  dsn_r(Rcpp::_["x"] = x, Rcpp::_["xi"] = xi, Rcpp::_["omega"] = omega, Rcpp::_["alpha"] = alpha);
    // Rcout << "dskew2: " << "  " << a << std::endl;
    return a;
  }
  

  // NumericVector ODE(double t, NumericVector bioms, NumericVector p){  // for sundials
  vec ODE(vec bioms, double t){ // for odeintr
    // here, the matricies of attack rates, handling times, feeding rates ...
    // are of diemnsions: nb species * nb consumers
    // so non square matrices
    // this is because I removed all the elements relative to a plant on a plant
    // it implies less claculations for the feeding rates
    // but more subsetting afterwards. 
    // not sure of the best option though 
    // (would it not be faster to use square matrices everywhere?)
    
    // Rcpp::Rcout << "aaa " << bioms.n_elem << std::endl;
    extinct = find(bioms < ext);
    bioms.elem(extinct).fill(0.0);
    // Rcpp::Rcout << bioms.t()  << std::endl;
    bioms_non_nut = bioms.elem(non_nut);
    pow_bioms = pow(bioms_non_nut, q);

    w = compute_w(bioms, log_BM, temperature);
    wb_mat = (w%b);
    wbh_mat = (w%b%h).t();
    // Rcout << "1 " <<  std::endl;
    F = wb_mat.each_col() % pow_bioms;
    // Rcpp::Rcout << "aaaa"  << std::endl;
    // wbh_mat*bioms: gives for each consumer i the sum over prey j of
    // wij*hij*bij*Bj
    // Rcout << "2 " <<  std::endl;
    low = wbh_mat*pow_bioms + c%bioms(animals) + 1;
    // Rcpp::Rcout << "bbbb"  << std::endl;
    // Rcout << "3 " <<  std::endl;
    low = low%BM(animals-nb_n);
    // Rcpp::Rcout << "low calculated: " << low.n_elem << std::endl;
    F.each_row() /=low.t();
    // Rcpp::Rcout << "F calculated"  << std::endl;
    // out_fluxes: sum of out flux for each resource species, col vector
    out_fluxes = F*bioms(animals);
    // Rcpp::Rcout << "out_fluxes"  << std::endl;
    // realised met. rate
    total_X = X%bioms(non_nut);
    // Rcpp::Rcout << "X"  << std::endl;
    // species specific growth factor for each plant
    // iterators are pointers, so not good here as I have to access to 
    // the ith element of different vectors
    for (res = 0; res != nb_b; ++res){
      // Rcpp::Rcout << res << "  ";
      G(res) = min(bioms(nut) / (K.col(res) + bioms(nut)));
      // Rcpp::Rcout << "!!" << res << "  " << G(res) << "  " << bioms(res+nb_n) << "-------";
    }
    // G could be calculated like that, not sure there is uch to win here though
    // Cholesky algs are in general in O(n^3)
    // KandBioms = k.each_col() + bioms(nut);
    // G = min(inv(KandBioms.each_col() / bioms(nut)), DIMENSION)

    // Rcpp::Rcout << "G: " <<  G.t() << std::endl;
    // plant uptake:
    uptake = r%bioms(plants)%G;
    // Rcpp::Rcout << std::endl << uptake.t() << std::endl;
    // derivatives for non nutrients
    dB(plants) = uptake - out_fluxes(plants-nb_n) - total_X(plants-nb_n);
     // Rcpp::Rcout << "db_plant"  << std::endl;  
    // dB(animals) = -out_fluxes(animals-nb_n) - total_X(animals-nb_n) + 
    //                       F.t()*(e%bioms(non_nut));
    dB(animals) = -out_fluxes(animals-nb_n) - total_X(animals-nb_n) + 
                      (F.t()*e)%bioms(animals);

    // Rcpp::Rcout << "V: " << V << std::endl;
    // Rcpp::Rcout << "db"  << std::endl;       
    // note: e may be preintegrated as constant ober time

    dB.elem(extinct).fill(0.0);
    // derivate for nutrients
    // dB(nut) = V*uptake;
     // Rcpp::Rcout << "V*uptake"  << std::endl;
    dB(nut) = D * (S - bioms(nut)) - V*uptake;
    // Rcpp::Rcout << dB(nut).t()  << std::endl; 
    // Rcpp::Rcout << "db_nuts"  << std::endl; 
    
    return(dB);
  }
  
};



RCPP_MODULE(Schneider_arma_prefModule){
  using namespace Rcpp;
  class_<Schneider_arma_pref>("Schneider_arma_pref")
    .constructor<int, int, int>("constructor") //constructor
    .method("print", &Schneider_arma_pref::print)
    .method("ODE", &Schneider_arma_pref::ODE)
    .method("initialisations", &Schneider_arma_pref::initialisations)
    .field("nb_s", &Schneider_arma_pref::nb_s)
    .field("nb_b", &Schneider_arma_pref::nb_b)
    .field("nb_n", &Schneider_arma_pref::nb_n)
    .field("BM", &Schneider_arma_pref::BM)
    .field("log_BM", &Schneider_arma_pref::log_BM)
    .field("K", &Schneider_arma_pref::K)
    .field("D", &Schneider_arma_pref::D)
    .field("S", &Schneider_arma_pref::S)
    .field("r", &Schneider_arma_pref::r)
    .field("X", &Schneider_arma_pref::X)
    .field("e", &Schneider_arma_pref::e)
    .field("w", &Schneider_arma_pref::w)
    .field("b", &Schneider_arma_pref::b)
    .field("c", &Schneider_arma_pref::c)
    .field("h", &Schneider_arma_pref::h)
    .field("q", &Schneider_arma_pref::q)
    .field("V", &Schneider_arma_pref::V)
    .field("temperature", &Schneider_arma_pref::temperature)
    .field("dB", &Schneider_arma_pref::dB)
    .field("D", &Schneider_arma_pref::D)
    .field("F", &Schneider_arma_pref::F)
    .field("uptake", &Schneider_arma_pref::uptake)
    .field("h", &Schneider_arma_pref::h)
    .field("fw", &Schneider_arma_pref::fw)
    .field("ext", &Schneider_arma_pref::ext)
    ;  
}
