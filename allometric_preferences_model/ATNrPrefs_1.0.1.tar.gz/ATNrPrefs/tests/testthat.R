library(testthat)
library(ATNrPrefs)

test_check("ATNrPrefs")
